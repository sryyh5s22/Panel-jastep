<?php 
$nik = "WEB CAHYO SR ||";
$sender = "admin@ftmnjasteb.com";
?>